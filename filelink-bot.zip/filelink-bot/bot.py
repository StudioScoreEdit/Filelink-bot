from pyrogram import Client, filters
from pyrogram.types import Message
import os

API_ID = int(os.getenv("API_ID"))
API_HASH = os.getenv("API_HASH")
BOT_TOKEN = os.getenv("BOT_TOKEN")
APP_URL = os.getenv("APP_URL")  # Set this later when deployed

bot = Client(
    "filelink-bot",
    api_id=API_ID,
    api_hash=API_HASH,
    bot_token=BOT_TOKEN
)

@bot.on_message(filters.private & filters.document)
async def file_handler(client, message: Message):
    msg = await message.reply("📥 Downloading your file...")

    file_path = await message.download()

    file_name = os.path.basename(file_path)
    download_link = f"{APP_URL}/{file_name}"

    os.rename(file_path, file_name)

    await msg.edit_text(
        f"✅ *Direct Download Link Ready!*\n\n"
        f"🔗 {download_link}"
    )

bot.run()
